//========================================================
//
//  File Name:   GraphType.h
//
//  Author:  Mark Baldwin
//
//  Course and Assignment:   CSCI490C-C Graphs
//
//  Description:  Header for the GraphType object
//
//=========================================================
#pragma once

#include <iostream>
#include <string.h> 
using namespace std;

//----------------------------------------------------------------------
//
// Object Graph
//
// Description: Class to hold a graph
//
//
//----------------------------------------------------------------------
class GraphType
{
public:
	GraphType(int mxsize);	// constructor
	~GraphType(void);	// destructor

	void MakeEmpty() ; // initializes the graph to an empty state
	bool AddVertex( string vertex ) ;  // adds a vertext to the graph
	bool AddEdge( string vertex1, string vertex2, int weight ) ;  // adds an edge
	int GetWeight( string vertex1, string vertex2 ) ;  // gets an edge weight
	bool GetAdjacent( string vertex1, int &count, string* vertex_array );  // gets the adjacent verticies
	void Print() ;	// print the graph

private:
	int IndexIs( string vertex ) ;  // gets the index of a vertex
	// int GetWeight( string vertex1, string vertex2 ) ;  // not implemented but probably will be needed 
	
	int m_mxVerticies ;   // maximum number of verticies in graph
	int m_numVerticies ; // number of verticies in the graph
	string *m_verticies ;   // name for each verticie
	int **m_edges ;			// 2 dimensional array of edges
};

