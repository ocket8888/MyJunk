//========================================================
//
//  File Name:   main.cpp
//
//  Author:  Mark Baldwin
//
//  Course and Assignment:   CSCI490C-C Graph Example
//
//  Description:  This code creates and test a graph using an
//  adjacency matrix.   
//
//=========================================================

//----- Includes and Namesapce ----------

#include <string> 
#include <iostream>
#include "GraphType.h"

using namespace std;

const int GraphMaxSize = 50 ;  // maximum number of verticies in the graph

//----------------------------------------------------------------------
//
// Name:  main()
//
// Description: Test driver for graph
//
// Inputs:
//    none
//
// Outputs:
//    returns 0
//
// Assumptions:
//    none
//
//----------------------------------------------------------------------
int main()
{
	string cmd ;  // command string
	GraphType testgraph(GraphMaxSize) ;  // the test graph

	// loop through a command loop to run varios hardwired test
	while( true ) // basically, an infinite loop
	{
		// get the comman
		cout << "Select command (INIT, ADDV, ADDE, GETE, PRINT, TEST1, QUIT): " ;
		getline( cin, cmd ) ;

		// reset the graph
		if( cmd == "INIT" ||      
			cmd == "init" )
		{
			testgraph.MakeEmpty() ;
			cout << "Graph is now empty." << endl ;
		}  // endif

		// add a vertex
		else if( cmd == "addv" ||      
			     cmd == "ADDV" )
		{
			cout << "Enter the name of the city: " ;
			getline( cin, cmd ) ;

			// if input
			if( cmd.length() != 0 )
			{
				if( testgraph.AddVertex( cmd ) )
				{
					cout << cmd << " has now been added to the graph." << endl ;
				}
				else
				{
					cout << "FAILURE: " << cmd << " has NOT been added to the graph." << endl ;
				}
			}  // end if
		}  // end if

		// add an edge
		else if( cmd == "adde" ||      
			     cmd == "ADDE" )
		{
			string v1, v2 ;
			int dist ;

			cout << "Enter the name of the first city: " ;
			getline( cin, v1 ) ;

			// the test are to make sure the inputs were good
			if( v1.length() != 0 )
			{
				cout << "Enter the name of the second city: " ;
				getline( cin, v2 ) ;

				if( v2.length() != 0 )
				{
					cout << "Enter the distance between the two cities: " << endl ;
					cin >> dist ;
					cin.ignore() ;  // we want to clear the input buffer before inputing a string.
					
					if( dist )
					{
						if( testgraph.AddEdge( v1, v2, dist ) )
						{
							cout << "An edge connecting " << v1 << " to " << v2 << " with a distance of " << dist << " was established." << endl ;
						}
						else
						{
							cout << "FAILURE: " << "An edge connecting " << v1 << " to " << v2 << " failed." << endl ;
						}
					}  // end if
				}  // end if
			}  // end if
		}  // end if

		// get an edge
		else if( cmd == "gete" ||      
			     cmd == "GETE" )
		{
			string v1, v2 ;

			cout << "Enter the name of the first city: " ;
			getline( cin, v1 ) ;

			// the test are to make sure the inputs were good
			if( v1.length() != 0 )
			{
				cout << "Enter the name of the second city: " ;
				getline( cin, v2 ) ;

				if( v2.length() != 0 )
				{
					// get the weight
					int dist = testgraph.GetWeight( v1, v2 ) ;

					if( dist != -1 )
					{
						cout << "The edge connecting " << v1 << " to " << v2 << " has a distance of " << dist << "." << endl ;
					}
					else
					{
						cout << "FAILURE: " << "There is no edge connecting " << v1 << " to " << v2 << "." << endl ;
					}  // end if
				}  // end if
			}  // end if
		}  // end if

		// print the current graph
		else if( cmd == "print" ||      
			     cmd == "PRINT" )
		{
				// print the graph
			testgraph.Print() ;
		}

		// load the graph with test 1 data
		else if( cmd == "test1" ||      
			     cmd == "TEST1" )
		{
			testgraph.MakeEmpty() ;  // empty the graph

				// add the test data to the graph
			testgraph.AddVertex( "Austin" ) ;
			testgraph.AddVertex( "Chicago" ) ;
			testgraph.AddVertex( "Dallas" ) ;
			testgraph.AddVertex( "Denver" ) ;
			testgraph.AddVertex( "Houston" ) ;
			testgraph.AddVertex( "Washington" ) ;
			testgraph.AddVertex( "Atlanta" ) ;

			testgraph.AddEdge( "Austin", "Dallas", 200 ) ;
			testgraph.AddEdge( "Austin", "Houston", 160 ) ;
			testgraph.AddEdge( "Chicago", "Denver", 1000 ) ;
			testgraph.AddEdge( "Dallas", "Austin", 200 ) ;
			testgraph.AddEdge( "Dallas", "Chicago", 900 ) ;
			testgraph.AddEdge( "Dallas", "Denver", 790 ) ;
			testgraph.AddEdge( "Denver", "Chicago", 1000 ) ;
			testgraph.AddEdge( "Denver", "Atlanta", 1400 ) ;
			testgraph.AddEdge( "Houston", "Atlanta", 800 ) ;
			testgraph.AddEdge( "Washington", "Atlanta", 600 ) ;
			testgraph.AddEdge( "Atlanta", "Washington", 600 ) ;
			testgraph.AddEdge( "Atlanta", "Houston", 800 ) ;

			cout << "Test case has been added." << endl ;
		}

		// quit the program
		else if( cmd == "quit" ||      
			     cmd == "QUIT" )
		{
			break ;  // exit the loop
		}
	}  // end do

	return 0;
} // end main

