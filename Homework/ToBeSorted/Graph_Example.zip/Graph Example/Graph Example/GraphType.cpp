//========================================================
//
//  File Name:   GraphType.cpp - Definitions for graphtype class
//
//  Author:  Mark Baldwin
//
//  Course and Assignment:   CSCI490C-C Graphs
//
//  Description:  This code creates and uses an graph.
//
//
//=========================================================
#include <string>
#include <iostream>
#include "GraphType.h"
using namespace std;

const int Null_Edge = -1 ;     // flag to say there is no edge

//------------------------------------------------------------------------
// Name:  GraphType::GraphType()
//
// Description: Default class constructor
//
// Arguments: 
//	int - maximum size of the graph
//
// Modifies: initializes class data
// 
// Returns: none
//
//--------------------------------------------------------------------
GraphType::GraphType(int mx_size)
{
	m_mxVerticies = mx_size ;   // max size of the graph
	m_numVerticies = 0 ;   // the current number of verticies
	m_verticies = new string[m_mxVerticies] ; // allocate space for verticies

	// Note, this is how you allocate dynamic 2 dimensional arrays
	m_edges = new int*[m_mxVerticies];  // this is an array of pointers, one for each row of the array
	for (int i = 0; i < m_mxVerticies; ++i)
	{
		m_edges[i] = new int[m_mxVerticies];   // then each row pointer points to a 1 dimensional array for the row
	}  // end for
}  // end GraphType


//------------------------------------------------------------------------
// Name:  GraphType::GraphType()
//
// Description: Default class destructor
//
// Arguments: none
//
// Modifies: initializes class data
// 
// Returns: none
//
//--------------------------------------------------------------------
GraphType::~GraphType(void)
{
	// IMPORTANT, always clean up any memory you allocated in the object
	delete [] m_verticies ;

	// this is for deleting a 2 dimensional dynamic array
	for (int i = 0; i < m_mxVerticies; ++i)
	{
		delete [] m_edges[i];
	}  // end for
	delete [] m_edges;

} // end ~GraphType

//------------------------------------------------------------------------
// Name:  GraphType::MakeEmpty()
//
// Description: empty the graph
//
// Arguments: 
//	none
//
// Modifies: 
//    m_nmVerticies
// 
// Returns: none
//
//--------------------------------------------------------------------
void GraphType::MakeEmpty()
{
	m_numVerticies = 0 ;   // zero out the number of verticies
}  // end MakeEmpty

//------------------------------------------------------------------------
// Name:  GraphType::AddVertex()
//
// Description: Add a vertex to the graph
//
// Arguments: 
//	string - vertex to be added
//
// Modifies:
//	m_edges - nulls out the edges associated with the vertex
//  m_numVerticies - is incremented
//	m_verticies - vertex is added
// 
// Returns: 
//	returns true if successful
//
//--------------------------------------------------------------------
bool GraphType::AddVertex( string vertex )
{
	// check to make sure array size is not exceeded
	if( m_numVerticies >= m_mxVerticies )
	{
		return false ;
	}  // end if

	m_verticies[m_numVerticies] = vertex ;   // add the vertex
	
	// clear out the edge 
	for( int index = 0 ; index <= m_numVerticies; index++ )
	{
		m_edges[m_numVerticies][index] = Null_Edge ;
		m_edges[index][m_numVerticies] = Null_Edge ;
	}  // end for

	// increment the number of verticies
	m_numVerticies++ ;

	return true ;  // success
}  // end AddVertex


//------------------------------------------------------------------------
// Name:  GraphType::IndexIs()
//
// Description: Finds the index associated with a vertex
//
// Arguments: 
//	string - vertex to be added
//
// Modifies:
//	none	
// 
// Returns: 
//	returns index if found, -1 if not found
//
//--------------------------------------------------------------------
int GraphType::IndexIs( string vertex )
{
	for( int index = 0; index < m_numVerticies ; index++ )
	{
		if( vertex == m_verticies[index] )  // we find a match
		{
			return index ;
		} // end if
	}  // end for

	return -1 ;  // could not be found
} // end IndexIs


//------------------------------------------------------------------------
// Name:  GraphType::AddEdge()
//
// Description: Add an edge to the graph
//
// Arguments: 
//	string vertex1, vertex2 - two verticies to be linked
//  int weight - Weight of edge
//
// Modifies:
//	m_edges
// 
// Returns: 
//	returns true if successful
//
//--------------------------------------------------------------------
bool GraphType::AddEdge( string vertex1, string vertex2, int weight )
{
	// get the indicies for each vertex
	int index1 = IndexIs( vertex1 ) ;
	int index2 = IndexIs( vertex2 ) ;

	// failed to find the vertex in the graph
	if( index1 == -1 ||
		index2 == -1 )
	{
		return false ;
	}  // end if

	// set the edges
	m_edges[index1][index2] = weight ;

	return true ;
}  // end AddEdge

//------------------------------------------------------------------------
// Name:  GraphType::GetWeight()
//
// Description: Gets the weight of an edge
//
// Arguments: 
//	string vertex1, vertex2 - two verticies to find edge
//
// Modifies:
//	none
// 
// Returns: 
//	weight of edge, -1 for failure
//
//--------------------------------------------------------------------
int GraphType::GetWeight( string vertex1, string vertex2 )
{
	// get the indicies for each vertex
	int index1 = IndexIs( vertex1 ) ;
	int index2 = IndexIs( vertex2 ) ;

	// failed to find the vertex in the graph
	if( index1 == -1 ||
		index2 == -1 )
	{
		return -1 ;
	}  // end if

	// check for no connect
	if( m_edges[index1][index2] == Null_Edge )
	{
		return -1 ;
	}

	// return weight
	return m_edges[index1][index2] ;

}  // end GetWeight

//------------------------------------------------------------------------
// Name:  GraphType::GetAdjacent()
//
// Description: Finds the verticies adjacent to a vertex
//
// Arguments: 
//	string vertex - vertex to test
//	int & - number of edges found
//  sting * - array to put verticies found
//
//  Important Note: The above arguments do not quite match the assignment. 
//                  Instead of returning a queue, I am returning the number
//                  of edges along with an array of the verticies.
//
// Modifies:
//	none
// 
// Returns: 
//	returns true if successful
//
//--------------------------------------------------------------------
bool GraphType::GetAdjacent( string vertex, int &nfound, string * vfound ) 
{

	int fromIndex = IndexIs( vertex ) ;
	nfound = 0 ;  // number of found edges

	if( fromIndex == -1 )  // the vertex was unknown
	{
		return false ;   // error
	} // end if

	for( int toIndex = 0 ; toIndex < m_numVerticies ; toIndex++ )
	{
		// if there is an edge
		if( m_edges[ fromIndex ][ toIndex ] != Null_Edge )
		{
			// put the vertice in the return array
			vfound[nfound] = m_verticies[ toIndex ] ;
			nfound++ ;  // and increment the count
		}  // end if
	}  // end for
	return true ;

} // end GetAdjacent 

//------------------------------------------------------------------------
// Name:  GraphType::Print()
//
// Description: Prints out the current Graph
//
// Arguments: 
//	none
//
// Modifies:
//	none
// 
// Returns: 
//	none
//
//--------------------------------------------------------------------
void GraphType::Print()
{
	string* vlist = new string[m_numVerticies] ;  // space to return adjacents
	int nedges ;	// number of edges

	cout << "Graph Print" << endl ;

	// print out each vertex, and then the connections
	for( int fromIndex = 0 ; fromIndex < m_numVerticies ;  fromIndex++ )
	{
		cout << "  City: " << m_verticies[fromIndex] << endl ;

		GetAdjacent( m_verticies[fromIndex], nedges, vlist ) ;

		if( nedges )
		{
			for( int i = 0 ; i < nedges ; i++ )
			{
				int toIndex = IndexIs( vlist[i] ) ;
				cout << "    Connects to: " << vlist[i] << "  Dist: " << m_edges[fromIndex][toIndex] << endl ;
			}  // end for
		}
		else
		{
			cout << "    City is not connected." << endl ;
		} // end if
	}  // end for
}  // end Print

