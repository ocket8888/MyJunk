#!/usr/bin/ruby

require "./words.rb"

class Words
	def [](i)
		return @wordList[i]
	end
end

words=Words.new
words.load

i = 0
until i == words.wordList.length
	print "Scrambled word: #{words[i].split("").shuffle.join}\n\nWhat's the word?\n"
	ans = STDIN.gets.chomp
	response = if ans == words[i] then "Yep, that's what that word is.\n" else "Nah dude, it was #{words[i]}\n" end
	print "#{response}Continue? (y/n): "
	cont = STDIN.gets.chomp.downcase
	print "\n"
	until cont.length == 1 and (cont == "y" or cont == "n")
		print "Let's try that one more time, Continue? (y/n): "
		cont = STDIN.gets.chomp.downcase
		print "\n"
	end
	if cont == "n"
		break		
	end
	i += 1
end

goodbye = if i == words.wordList.length then "No more words yo.\n" else "Okay, looks like you're done here.\n" end

print goodbye	