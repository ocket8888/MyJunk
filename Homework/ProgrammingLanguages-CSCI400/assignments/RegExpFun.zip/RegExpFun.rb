#!/usr/bin/ruby

#A suite of Regular Expression Functions
#designed to make RegExpFunTester's tests pass
module RegExpFun

	#strips trailing 'is cool' from a string
	def get_language(str)
		return /(.+)\sis cool$/.match(str)[1]
	end

	#gets the last word from a string
	def get_adjective(str)
		return /(^|\s)(\w+)$/.match(str)[2]
	end

	#gets the first occurency of a USD currency
	#substring from a string
	def get_price(str)
		return /.*(\$\d+\.\d{2}).*/.match(str)[1]
	end

	#returns true if the string is a complex number,
	#false otherwise
	def is_complex(str)
		return (if (/\A(\+|-)?((\d+(((\+|-)\d*i)|i))|i)\z/.match(str) != nil) then 0 else nil end)
	end
end