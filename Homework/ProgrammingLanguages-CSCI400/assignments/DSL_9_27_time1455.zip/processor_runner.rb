require './processor.rb'

Processor.instance.run_system