#!/usr/bin/ruby
require "minitest/autorun"
require "./words.rb"

class TestWords < MiniTest::Unit::TestCase
	def setup
		@words = Words.new
	end

	def test_load
		@words.load
		refute_nil(@words.wordList)
	end

	def test_random
		@words.setwordList(["a".."z"])
		mcount = 0
		for i in [1..100] do
			if @words.getWord == "m"
				mcount += 1
			end
		end
		assert(mcount < 10)
	end
end