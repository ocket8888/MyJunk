
<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <title>PHP Example</title>
  </head>
  <body>
    <div class="page-header">
      <h1>WoW Character Datasheet</h1>
    </div>
    <div class="well well-lg" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center;">
      <form action="character.php" method="post">
        <div class="input-group">
        <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
        <input placeholder="Character Name" type="text" name="name"><br>
        </div>
        <div class="input-group">
        <span class="input-group-addon"><span class="glyphicon glyphicon-cloud"></span></span>
        <input placeholder="Realm" type="text" name="realm"><br>
        </div>
        <input type="submit" class="btn btn-default">
      </form>
    </div>
  </body>
</html>

