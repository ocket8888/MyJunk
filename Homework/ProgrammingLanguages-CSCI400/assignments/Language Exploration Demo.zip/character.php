<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/angular_material/1.1.0/angular-material.min.css">
	<title>Character Data</title>
	<style type="text/css">
		md-content {
			background-color: #EAEAFA !important;
		}
		img#profilemain {
			max-width: 538px;
			max-height: 400px;
		}
		div#page-header {
			font-size: 18pt;
			font-weight: bold;
			background-color: white;
			padding-left: 5px;
			padding-top: 5px;
		}
		md-list.stat-list {
			max-height: 400px;
			overflow-y = auto;
		}
	</style>
</head>
<!-- we loaded angular.js, because it makes making fluid divs really easy, and the point of
the project wasn't to show off how well we know css -->
<body ng-app="chardat" ng-cloak>
<script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular-animate.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular-aria.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular-messages.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/angular_material/1.1.0/angular-material.min.js"></script>
<script type="text/javascript">
angular.module('chardat', ['ngMaterial']);
</script>
<md-content layout="column" layout-fill>
<?php

	//This bit sets up dictionaries that turn numbers returned as values for "race" "class"
	// and "gender" fields of characters into their respective names.
	  $classesFile = fopen("./classes.json", "r") or die("Couldn't open local files!");
	  $racesFile = fopen("./races.json", "r") or die("Couldn't open local files!");

	  $classesData = json_decode(fread($classesFile, filesize("classes.json")), true);
	  $racesData = json_decode(fread($racesFile, filesize("races.json")), true);

	  $classes = array();
	  foreach ($classesData["classes"] as $class => $data) {
	  	$classes[$data["id"]] = ["mask" => $data["mask"], "powerType" => $data["powerType"], "name" => $data["name"]];
	  }

	  $races = array();
	  foreach ($racesData["races"] as $race => $data) {
  		$races[$data["id"]] = ["mask" => $data["mask"], "side" => $data["side"], "name" => $data["name"]];
	  }

	  $genders = [0 => "Male", 1 => "Female"];

	  

	  //don't look at this function. We needed to format the name of each stat on a case-by-case
	  //basis; there was no pretty way to do it.
	  function formatStat($stat)
	  {
	  	if ($stat == "agi") {
	  		return "Agility";
	  	}
	  	elseif ($stat == "str") {
	  		return "Strength";
	  	}
	  	elseif ($stat == "int") {
	  		return "Intelligence";
	  	}
	  	elseif ($stat == "sta") {
	  		return "Stamina";
	  	}
	  	elseif ($stat == "speedRating") {
	  		return "Speed";
	  	}
	  	elseif ($stat == "speedRatingBonus") {
	  		return "Speed Bonus";
	  	}
	  	elseif ($stat == "crit") {
	  		return "Critical Chance (percent)";
	  	}
	  	elseif ($stat == "critRating") {
	  		return "Critical Rating";
	  	}
	  	elseif ($stat == "haste") {
	  		return "Haste";
	  	}
	  	elseif ($stat == "hasteRating") {
	  		return "Haste Rating";
	  	}
	  	elseif ($stat == "hasteRatingPercent") {
	  		return "Haste Rating (Percent)";
	  	}
	  	elseif ($stat == "mastery") {
	  		return "Mastery";
	  	}
	  	elseif ($stat == "masteryRating") {
	  		return "Mastery Rating";
	  	}
	  	elseif ($stat == "leech") {
	  		return "Leech";
	  	}
	  	elseif ($stat == "leechRating") {
	  		return "Leech Rating";
	  	}
	  	elseif ($stat == "leechRatingBonus") {
	  		return "Leech Rating Bonus";
	  	}
	  	elseif ($stat == "versatility") {
	  		return "Versatility";
	  	}
	  	elseif ($stat == "versatilityDamageDoneBonus") {
	  		return "Versatility Bonus from Damage Dealt";
	  	}
	  	elseif ($stat == "versatilityHealingDoneBonus") {
	  		return "Versatility Bonus from Healing";
	  	}
	  	elseif ($stat == "versatilityDamageTakenBonus") {
	  		return "Versatility Bonus from Damage Taken";
	  	}
	  	elseif ($stat == "avoidanceRating") {
	  		return "Avoidance Rating";
	  	}
	  	elseif ($stat == "avoidanceRatingBonus") {
	  		return "Avoidance Rating Bonus";
	  	}
	  	elseif ($stat == "spellPen") {
	  		return "Spell Penetration";
	  	}
	  	elseif ($stat == "spellCrit") {
	  		return "Spell Critical Chance (Percent)";
	  	}
	  	elseif ($stat == "spellCritRating") {
	  		return "Spell Critical Rating";
	  	}
	  	elseif ($stat == "mana5") {
	  		return "Mana";
	  	}
	  	elseif ($stat == "mana5Combat") {
	  		return "Mana Combat";
	  	}
	  	elseif ($stat == "armor") {
	  		return "Armor";
	  	}
	  	elseif ($stat == "dodge") {
	  		return "Dodge Chance (Percent)";
	  	}
	  	elseif ($stat == "dodgeRating") {
	  		return "Dodge Rating";
	  	}
	  	elseif ($stat == "parry") {
	  		return "Parry Chance (Percent)";
	  	}
	  	elseif ($stat == "parryRating") {
	  		return "Parry Rating";
	  	}
	  	elseif ($stat == "block") {
	  		return "Block Chance (Percent)";
	  	}
	  	elseif ($stat == "blockRating") {
	  		return "Block Rating";
	  	}
	  	elseif ($stat == "mainHandDmgMin") {
	  		return "Minimum Main Hand Damage";
	  	}
	  	elseif ($stat == "mainHandDmgMax") {
	  		return "Maximum Main Hand Damage";
	  	}
	  	elseif ($stat == "mainHandSpeed") {
	  		return "Main Hand Attack Speed";
	  	}
	  	elseif ($stat == "mainHandDps") {
	  		return "Main Hand Base DPS";
	  	}
	  	elseif ($stat == "offHandDmgMin") {
	  		return "Minimum Off-Hand Damage";
	  	}
	  	elseif ($stat == "offHandDmgMax") {
	  		return "Maximum Off-Hand Damage";
	  	}
	  	elseif ($stat == "offHandSpeed") {
	  		return "Off-Hand Attack Speed";
	  	}
	  	elseif ($stat == "offHandDps") {
	  		return "Off-Hand Base DPS";
	  	}
	  	elseif ($stat == "rangedDmgMin") {
	  		return "Minimum Ranged Damage";
	  	}
	  	elseif ($stat == "rangedDmgMax") {
	  		return "Maximum Ranged Damage";
	  	}
	  	elseif ($stat == "rangedSpeed") {
	  		return "Ranged Attack Speed";
	  	}
	  	elseif ($stat == "rangedDps") {
	  		return "Base Ranged DPS";
	  	}
	  	return "Unkown";
	  }

	  //here we use the `php_curl` module to fetch character data from Blizzard's API based on
	  //the parameters that were passed to this page. (due to poor documentation on Blizzard's
	  //part, there's no error checking because there's no way to tell what could be returned on
	  //error)
      $ch = curl_init();
      $url = "https://us.api.battle.net/wow/character/" . $_POST["realm"] . "/" . $_POST["name"] . "?fields=guild+items+stats&locale=en_US&apikey=v5ujumegrnn56saps4aphfq6vpgup4a3";
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      $response = json_decode(curl_exec($ch), true);
      curl_close($ch);

      //these make accessing stats and items a little easier, and less bracket-heavy
      $playerStats = $response["stats"];
      $equippedItems = $response["items"];


	//The first part here prints out the character's name in a header, a picture of the character,
      // and some basic information e.g. level race etc.
      echo "<div id='page-header'>". $response["name"] ."</div>
      		<md-content layout-fill layout='row' layout-padding>
      			<img id='profilemain' src='http://render-api-us.worldofwarcraft.com/static-render/us/" . preg_replace("/avatar/", "profilemain", $response["thumbnail"]) . "' />
      			<md-divider></md-divider>
      			<md-list flex='40' layout='column'>
      				<md-list-item class='md-1-line'>Level: " . $response["level"] . "</md-list-item>
      				<md-list-item class='md-1-line'>Class: " . $classes[$response["class"]]["name"] . "</md-list-item>
      				<md-list-item class='md-1-line'>Race: " . $races[$response["race"]]["name"] . "</md-list-item>
      				<md-list-item class='md-1-line'>Gender: " . $genders[$response["gender"]] . "</md-list-item>
      				<md-list-item class='md-1-line'>Battlegroup: " . $response["battlegroup"] . "</md-list-item>
      				<md-list-item class='md-1-line'>Achievement Points: " . $response["achievementPoints"] . "</md-list-item>
      				<md-list-item class='md-1-line'>Honorable Kills: " . $response["totalHonorableKills"] . "</md-list-item>
      			</md-list>
      			<div flex='60' layout=column>
      				<md-card ng-init='iexpand = false'>
      					<md-header class='layout-row' layout-align='space-between center'>
      						<div>Items</div>
      						<md-button class='md-raised' ng-click='iexpand = !iexpand'>{{iexpand ? '-' : '+'}}</md-button>
      					</md-header>
      					<md-content ng-show='iexpand'>
      						<md-list class='stat-list' flex layout='column'>
      							<md-list-item class='md-1-line'>I-Level: ". $equippedItems["averageItemLevel"] . "</md-list-item>
      							<md-list-item class='md-1-line'>I-Level (Equipped): ". $equippedItems["averageItemLevelEquipped"] . "</md-list-item>";
      
      //After already outputting I-Level and equipped I-Level, we remove those and loop over the rest of the info,
      //since it's all well-structured
      unset($equippedItems["averageItemLevel"]);
      unset($equippedItems["averageItemLevelEquipped"]);
      foreach ($equippedItems as $slot => $item) {
      	echo "\n<md-list-item class='md-3-line'>
      			<div class='md-list-item-text' layout='column'>
	      			<h3>{{'". $slot ."' | uppercase}}</h3>
	      			<h4>". $item["name"] ."</h4>
	      			<p>I-Level: ". $item["itemLevel"] ."</p>
	      		</div>
      		  </md-list-item>";
      }


      //under here we print stats (with some special handling for 'power', since the 'power' of a character goes by
      //different names for different classes e.g. Death Knights have 'Runic Power', Monks have 'Energy')
      echo "				</md-list>
      					<md-content>
      				</md-card>
      				<md-card ng-init='sexpand = false'>
      					<md-header class='layout-row' layout-align='space-between center'>
      						<div>Stats</div>
      						<md-button class='md-raised' ng-click='sexpand = !sexpand'>{{sexpand ? '-' : '+'}}</md-button>
      					</md-header>
      					<md-content ng-show='sexpand'>
      						<md-list class='stat-list' flex layout='column'>
      							<md-list-item class='md-1-line'>
      								<div class='md-list-item-text'>Max Hp: ". $playerStats["health"] ."</div>
      							</md-list-item>
      							<md-list-item class='md-1-line'>
      								<div class='md-list-item-text'>Max ". $playerStats["powerType"] .": ". $playerStats["power"] ."</div>
      							</md-list-item>";

      	//after special handling, print out the stats. Don't look at the `formatStat` function. We're not proud of it.
        unset($playerStats["health"]);
        unset($playerStats["power"]);
        unset($playerStats["powerType"]);
        foreach ($playerStats as $stat => $value) {
        	if ($value >= 0) {
        		echo "\n<md-list-item class='md-1-line'>
        			<div class='md-list-item-text'>". formatStat($stat) .": ". $value ."</div>
        			</md-list-item>";
        	}
        }
      echo "
      						</md-list>
      					</md-content>
      				</md-card>
      			</div>
      		</md-content>";
?>
<md-content>
</body>
</html>