#!/usr/bin/ruby
require 'minitest/autorun'
require './nim.rb'

#Just play smart ai versus dumb ai 20 times
game=Nim.new
game.add_player(Smart_computer.new)
game.add_player(Dumb_computer.new)
for i in (0..19)
    game.choose_board(0)
    game.play
end