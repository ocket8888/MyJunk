#!/usr/bin/ruby
require 'minitest/autorun'
require './nim.rb'

#This class will test the various methods of 
#Smart_computer in Nim.rb
class NimTester < MiniTest::Unit::TestCase
    # setup the game for testing
    def setup
        @game = Nim.new
        @game.choose_board(0)
        @comp = Smart_computer.new
    end
    
    def smart_test
        board = [["X", "X", "X"], ["X", "X", "X"], 
            ["X", "X", "X", "X", "X", "X"]]
        @comp.take_turn(board)
        nim_sum = 0
		board.each{|row| nim_sum ^= row.length}
        assert_equal(0, nim_sum)
    end

end