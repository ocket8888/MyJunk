/*destroys existing tables named 'books1' and/or 'books2' for clean starts on each run*/ 
drop table if exists books1;
drop table if exists books2;
drop table if exists books;

/*Step 1: Create the table*/
create table books1 (
number int not null,
title varchar(50),
isbn varchar(17),
publicationdate Date,
pages int,
primary key (number)
);

/*Step 2: Insert the Data*/
insert into books1 (number, title, isbn, publicationdate, pages)
	values (1, 'Harry Potter and the Philosopher''s Stone', '0-7475-3269-9', '1997-06-26', 223);
insert into books1 (number, title, isbn, publicationdate, pages)
	values (2, 'Harry Potter and the Chamber of Secrets', '0-7475-3849-2', '1998-07-02', 251);
insert into books1 (number, title, isbn, publicationdate, pages)
	values (3, 'Harry Potter and the Prisoner of Azkaban', '0-7475-4215-5', '1999-07-08', 317);
insert into books1 (number, title, isbn, publicationdate, pages)
	values (4, 'Harry Potter and the Goblet of Fire', '0-7475-4624-X', '2000-07-08', 636);
insert into books1 (number, title, isbn, publicationdate, pages)
	values (5, 'Harry Potter and the Order of the Phoenix', '0-7475-5100-6', '2003-06-21', 766);
insert into books1 (number, title, isbn, publicationdate, pages)
	values (6, 'Harry Potter and the Half-Blood Prince', '0-7475-8108-8', '2005-07-16', 607);
insert into books1 (number, title, isbn, publicationdate, pages)
	values (7, 'Harry Potter and the Deathly Hallows', '0-545-01022-5', '2007-07-21', 607);
insert into books1 (number, title, isbn, publicationdate, pages)
	values (8, 'Harry Potter and the Bunnies of Doom', '1-234-56789-0', '2010-01-15', null);

/*Step 3: Fix Errors*/
/*I used the primary key, because otherwise why have one, ya' know?*/
delete from books1 where number=8;

/*Step 5: Create a Second Table and Copy Data*/
create table books2 as (select * from project3_us_books);

/*Step 6: Create the Final Table*/
create table books (
number int not null,
title varchar(50) not null,
isbn varchar(17) not null unique,
publicationdate date not null,
pages int,
ustitle varchar(50),
uspublicationdate date,
uspages int,
primary key (number)
);

/*Step 7: Populate Books*/
insert into books (number, title, isbn, publicationdate, pages, ustitle, uspublicationdate, uspages)
	select books1.number, books1.title, books1.isbn, books1.publicationdate, books1.pages, null, books2.publicationdate, books2.pages
	from books1, books2 where books1.number=books2.number;

/*Step 8: Create the US titles*/
update books set ustitle=title;

/*Step 9: Fix Errors*/
update books set ustitle='Harry Potter and the Sorceror''s Stone' where number=1;

/*I just like to make sure I get the proper results*/
select * from books;
select * from books1;
select * from books2;