/*#1 Number of students such that they have house='Slytherin'*/
select count(*) from hogwarts_students where house='Slytherin';

/*#2 Earliest student start date*/
select start from hogwarts_students where start is not null order by start limit 1;

/*#3 Number of students with missing information (first/last names cannot be missing)*/
select count(*) from hogwarts_students where house is null or start is null or finish is null;

/*#4 Number of students with no missing information (first/last names cannot be missing)*/
select count(*) from hogwarts_students where house is not null and start is not null and finish is not null;

/*#5 Each house and its number of students in order of most students to least*/
select house, count(*) as number from hogwarts_students group by house order by number desc;

/*#6 Name and starting year of earliest known student*/
select (first || ' ' || last) as name, start from hogwarts_students where start is not null order by start limit 1;

/*#7 Number of students from each house that started the year Alastor Moody was appointed Defense Against the Dark Arts Teacher*/
select house, count(*) as number from hogwarts_students where start in (select start from hogwarts_dada where first='Alastor' and last='Moody') group by house order by number desc;

/*#8 Names, houses, and house colors of hogwarts students who went on to teach Defense Against the Dark Arts*/
select (hogwarts_students.first || ' ' || hogwarts_students.last) as name, hogwarts_students.house, hogwarts_houses.colors as house_colors from hogwarts_students left join hogwarts_houses on hogwarts_students.house=hogwarts_houses.house where first in (select first from hogwarts_dada group by first) and last in (select last from hogwarts_dada group by last);

/*#9 Records for students that were in Gryffindor house and had Gilderoy Lockhart as a Defense Against the Dark Arts Teacher*/
select * from hogwarts_students where start is not null and finish is not null and house='Gryffindor' and ((select start from hogwarts_dada where first='Gilderoy' and last='Lockhart') between start and finish or (select finish from hogwarts_dada where first='Gilderoy' and last='Lockhart') between start and finish);
