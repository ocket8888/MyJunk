/*#1 Nymphadora Tonks's starting year*/
select start from hogwarts_students where first='Nymphadora' and last='Tonks';

/*#2 Student records who started before 1990*/
select * from hogwarts_students where start<1990;

/*#3 House Padma Patil was sorted into*/
select house from hogwarts_students where first='Padma' and last='Patil';

/*#4 Number of years Percy Weasly attended Hogwarts*/
select finish-start as years from hogwarts_students where first='Percy' and last='Weasly';

/*#5 Student records with last names starting with 'Q' and/or first name starting with 'Ph'*/
select * from hogwarts_students where first like 'Q%' or last like 'Ph%';

/*#6 Student records with unknown house affiliation*/
select * from hogwarts_students where house is null;

/*#7 Founder of the house featuring a badger on its crest*/
select founder from hogwarts_houses where lower(animal)='badger';

/*#8 Names of all Gryffindor students in 'first last' format*/
select (first || ' ' || last) as name from hogwarts_students where house='Gryffindor';

/*#9 DA teacher records whose first names begin with 'A' and whose last names don't start with 'M'*/
select * from hogwarts_dada where first like 'A%' and last not like 'M%';

/*#10 Student records who started in 1991 ordered by last name, then first name*/
select * from hogwarts_students where start=1991 order by last, first;

/*#11 Unique finishing years, in ascending order*/
select finish from hogwarts_students group by finish order by finish;

/*#12 The names and colors of all students whose houses are known, ordered by the year they started*/
select (hogwarts_students.first || ' ' || hogwarts_students.last) as Name, hogwarts_houses.colors, hogwarts_students.start from hogwarts_students left join hogwarts_houses on (hogwarts_students.house=hogwarts_houses.house) where hogwarts_students.house is not null order by start;


/*#13 Founder of house Morag McDougal was sorted into*/
select founder from hogwarts_houses where house in (select house from hogwarts_students where first='Morag' and last='McDougal');

/*#14 Names and houses of DA teachers*/
select first, last, house from hogwarts_students where (first || last) in (select (first || last) as name from hogwarts_dada);