/*Drop the tables to start fresh*/
/*(I'm using `cascade`, but I don't trust it, so I drop every table)*/
drop table if exists Artist cascade;
drop table if exists Members cascade;
drop table if exists Label cascade;
drop table if exists Album cascade;
drop table if exists Track cascade;

create table Artist(
	ID serial primary key,
	Name text,
	IsGroup boolean
);

create table Members(
	GroupID integer references Artist(ID),
	MemberID integer references Artist(ID),
	BeginYear integer,
	EndYear integer,
	primary key(GroupID, MemberID)
);

create table Label(
	ID serial primary key,
	Name text,
	Location text
);

create table Album(
	ID serial primary key,
	Title text,
	Year integer,
	Genres text[],
	PublishedBy integer references Label(ID),
	ReleasedBy integer references Artist(ID)
);

/*'TrackNumber' would be 'Number', but that's a datatype*/
/*and I wanted to avoid confusion/errors*/
create table Track(
	Name text,
	TrackNumber text,
	IsSongOn integer references Album(ID) not null,
	primary key(Name, TrackNumber, IsSongOn)
);


/*gets all individual and group artists and inserts them into 'Artist'*/
insert into Artist (Name, IsGroup) (
	select distinct artist_name, (case
                                    when artist_type='Group' then cast('true' as boolean)
                                    else cast('false' as boolean)
                                  end) as IsGroup
	from public.project7
union
	select distinct member_name, cast('false' as boolean) from public.project7);

/*gets all members of groups and inserts the appropriate cross-reference into 'Members'*/
insert into Members (GroupID, MemberID, BeginYear, EndYear)
	select gid, mid, start, term from
		(select gid, mname, start, term
		from
			(select distinct
				artist_name as gname,
				member_name as mname,
				member_begin_year as start,
				member_end_year as term
			from public.project7 where artist_type='Group')
		as memberlist inner join
			(select ID as gid, name from Artist where IsGroup) as groups
		on groups.name=memberlist.gname)
	as grouped
	inner join (select Name, ID as mid from Artist where not IsGroup) as individuals
	on mname=name order by mid;

/*populates the 'Label' table, pretty easy.*/
insert into Label (Name, Location)
	select distinct label, headquarters from public.project7;

/*populates the 'Album' table*/
insert into Album (Title, Year, Genres, PublishedBy, ReleasedBy)
	select distinct	album_title, album_year, genres, Label.ID, Artist.ID
	from public.project7
	inner join Label on Label.Name=public.project7.label
	inner join Artist on Artist.Name=artist_name
	inner join (select distinct title, array_agg(genre) over (partition by title) as genres
				from
					(select distinct public.project7.album_title as title, genre from project7) as genrelist) as iranoutofnamessueme
		on iranoutofnamessueme.title=public.project7.album_title;

/*populates the 'Track' table*/
insert into Track (Name, TrackNumber, IsSongOn)
	select tname, tno, Album.ID
	from
		(select distinct track_name as tname, track_number as tno, album_title
		from project7) as alltracks
	inner join Album on Title=album_title;

/*Returns all members of 'The Who' and their start and (if applicable) end dates*/
select Name, BeginYear, EndYear from Members
inner join Artist on ID in
	(select MemberId where GroupID in
		(select Id from Artist where Artist.Name='The Who'))
order by BeginYear, Name;

/*Lists the artist groups that Chris Thile is or was a part of*/
select Name from Artist where ID in
	(select GroupID from Members where MemberID in
		(select ID from Artist where Name='Chris Thile'));

/*Lists any album this Chris Thile guy ever contributed to*/
select Title, Year, Artist.Name as artist, Label.Name as label from Album
inner join Artist on Artist.Id=ReleasedBy
inner join Label on Label.Id=PublishedBy
where ReleasedBy in
	(select	ID
		from Artist where ID in
			(select GroupID from Members where MemberID in
				(select ID from Artist where Name='Chris Thile'))
		or ID in (select ID from Artist where Name='Chris Thile'));
/*no cheating here; how am I to know what groups he's a part of?*/

/*lists all electronica albums*/
select Name, Title, Year from Album
inner join Artist on Artist.Id=ReleasedBy
where 'electronica'=any(Genres);

/*returns the tracklist from "Led Zepplin"'s "Houses of the Holy" album*/
select Name, TrackNumber from Track where IsSongOn in
	(select ID from Album where
		Title='Houses of the Holy' and
		ReleasedBy in
			(select ID from Artist where Artist.Name='Led Zeppelin'))
order by TrackNumber;

/*gets the genres that James Taylor has performed in*/
select distinct unnest(genres) as genre from
	(select genres from Album
	where ReleasedBy in
		(select ID from Artist where Name='James Taylor')
	or ReleasedBy in 
		(select GroupID from Members where MemberID in
			(select ID from Artist where Name='James Taylor'))) as albumlist;

/*albums published by Hollywood labels*/
select Artist.Name, Title, Year, Label.Name from Artist
inner join Album on Artist.ID=ReleasedBy
inner join Label on Label.ID=PublishedBy
where Location='Hollywood';